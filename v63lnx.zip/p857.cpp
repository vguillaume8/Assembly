#include <iostream>
using namespace std;
int x;
int main()
{
   for (x = 0; x <= 10; x++)
      cout << "hello\n";
   return 0;
}
