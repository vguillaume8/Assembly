class OaTest {
 public static void main(String arg[]) 
 {
    O o;               
    int a[];
    o = new O();
    o.x = 6;    
    o.f();      
    a = new int[7];
    a[5] = 3;      
 }              
}
