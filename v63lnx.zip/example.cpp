#include <iostream>
using namespace std;
int x;
int main() 
{
  x = 5;
  cout << x << endl;
  return 0;
}    