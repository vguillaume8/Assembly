int f()
{
   return 5;
}
int main()
{
   f();
   return 0;
}
