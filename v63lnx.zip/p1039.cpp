void test()
{
  return;
}
int main()
{
  tesst();
  return 0;
}
