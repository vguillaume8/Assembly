#include <iostream>
using namespace std;
void f()
{
   int x;
   x = 1;
   int y;
   y = 2;
   cout << x << " " << y << endl;
}
int main()
{
   f();
   return 0;
}
